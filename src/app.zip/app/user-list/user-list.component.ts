// import { Component, OnInit } from '@angular/core';
// import { DataService } from '../services/data.service';
// import { CommonModule } from '@angular/common';
// import { Observable, map } from 'rxjs';

// @Component({
//   selector: 'app-user-list',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './user-list.component.html',
//   styleUrls: ['./user-list.component.css']
// })
// export class UserListComponent implements OnInit {
//   users$!: Observable<any[]>; // Observable of an array of users
//   errorMessage: string = '';

//   constructor(private dataService: DataService) {}

//   ngOnInit(): void {
//     this.users$ = this.dataService.getUsers().pipe(
//       map((data) => (Array.isArray(data) ? data : [data])) // Ensure the response is always an array
//     );
//   }
// }

// import { Component, OnInit } from '@angular/core';
// import { DataService } from '../services/data.service';
// import { CommonModule } from '@angular/common';
// import { Observable, map } from 'rxjs';

// @Component({
//   selector: 'app-user-list',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './user-list.component.html',
//   styleUrls: ['./user-list.component.css']
// })
// export class UserListComponent implements OnInit {
//   users$!: Observable<any>; // Observable of either an array or a single object
//   errorMessage: string = '';

//   constructor(private dataService: DataService) {}

//   ngOnInit(): void {
//     this.users$ = this.dataService.getUsers().pipe(
//       map((data) => (Array.isArray(data) ? data : [data])) // Ensure the response is always an array
//     );
//   }
// }

import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  users$!: Observable<any>; // Observable of the API response
  errorMessage: string = '';

  constructor(private dataService: DataService) {}

  ngOnInit(): void {
    this.users$ = this.dataService.getUsers(); // Directly use the API response
  }

  isArray(value: any): boolean {
    return Array.isArray(value); // Helper method to check if a value is an array
  }
}