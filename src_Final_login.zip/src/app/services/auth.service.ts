// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable, tap } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   logout() {
//     sessionStorage.clear(); // Clear all session storage, including guest mode
//   }
// }
